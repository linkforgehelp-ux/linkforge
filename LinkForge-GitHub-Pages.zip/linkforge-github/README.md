# LinkForge

A static GitHub Pages version of the supplied LinkForge web app.

## Run it on your computer

You do **not** need Node.js, React, npm, or a database for the current version.

### Easiest
Double-click `index.html` and open it in a browser.

### Recommended local server
If your browser behaves differently when opening a file directly, use Python:

```bash
cd linkforge-github
python -m http.server 8000
```

Then open:

http://localhost:8000

Stop the server with `Ctrl+C`.

## Publish on GitHub Pages

1. Create a new GitHub repository, for example `linkforge`.
2. Upload **everything in this folder**. Make sure `index.html` is in the repository root.
3. On GitHub open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then Save.
6. GitHub will give you the live Pages URL.

GitHub Pages is static hosting, so this project works without a build step.

## Important: what is and is not production-ready

The supplied app is already a self-contained frontend and its JavaScript passes a syntax check. It stores its demo account/profile/chat/settings data in the browser's `localStorage`.

The current version includes **demo** behavior for:
- account creation/login
- email verification
- plan/payment flow
- AI assistant responses
- messaging

Those features are not connected to a real server. For example, the signup flow explicitly describes the verification code as a demo and says a production version should deliver it by email. The payment screen also labels its payment flow as demo behavior. So GitHub Pages can make the UI live, but it cannot by itself provide real authentication, email delivery, payments, databases, or secret API keys.

For a real production LinkForge, the next step would be to add a backend/database and connect:
- authentication + password reset
- real email verification
- a real payment provider
- persistent user profiles/links/messages
- a secure AI API endpoint (never put an AI API key directly in `index.html`)

## Updating the site

After changing `index.html`:

```bash
git add .
git commit -m "Update LinkForge"
git push
```

GitHub Pages will redeploy the updated static site.

## Project structure

```text
linkforge/
├── index.html
├── .nojekyll
└── README.md
```
